# 15단계 검증 근거 읽는 순서

1. 최종 배포본 독립 검증: package_report.json, package_00~16 로그, package_verification/results.json.
2. 최종 GL 캡처: gl_final.log, capture.json, capture_metrics.json, docs/stage15_map_review.
3. 최종 지형: landing_terrain.json, world_validation.json, 보존 검사 preservation_audit.json.
4. 최종 아트: carved_art_qa.json, art/quality.json, art/repack.json, background_render_parity.json.
5. 시작 상태/초안: baseline_terrain.json, first_layout_draft.json, landing_draft_terrain.json, retired_source, before. 실패 기록은 초기 상태 또는 수정 이전 시행의 근거로 보존했습니다.

headless/와 full_checks.log는 최적화 전 195/196 통과 당시 기록입니다. 최종 결과로 혼동하지 마세요. 최종 배포본 기록은 1번입니다.

렌더 원본 2장은 art/generated_materials.png와 art/generated_landing_sea.png입니다. canonical과 before는 변환 품질 비교 기준입니다. 게임 이미지가 아닌 QA 비교/접합 몽타주는 PIL로 구성했습니다.
