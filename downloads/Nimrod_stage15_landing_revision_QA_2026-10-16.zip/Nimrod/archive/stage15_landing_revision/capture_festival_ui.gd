extends "res://tests/helpers/stage9_support.gd"
func _run() -> void:
    await _start9()
    story_state.debug_stage(21)
    root.get_node("GameState").switch_character("siyavash")
    await _go("HwaniraPlaza")
    var world: Node=root.get_node("World")
    world.invulnerable=true
    await world.enter()
    hero.set_physics_process(false)
    hero.position=Vector2(40,74)*32
    world.schedule_stream(hero.position)
    while not world.streaming_idle():await process_frame
    for id: String in world.abilities_data.abilities:world.abilities[id]=true
    hero.camera.position_smoothing_enabled=false
    hero.camera.reset_smoothing()
    hero.camera.force_update_scroll()
    for i in range(8):await process_frame
    if DisplayServer.get_name()!="headless":
        await RenderingServer.frame_post_draw
        root.get_texture().get_image().save_png("res://docs/stage15_map_review_revision/festival_ability_hud.png")
    _check(world.map_ui.ability_strip.visible,"Acquired abilities appear without a text summary")
    world.map_ui.open_map()
    for i in range(5):await process_frame
    _check(paused and world.map_ui.opened,"Map pauses the world")
    if DisplayServer.get_name()!="headless":
        await RenderingServer.frame_post_draw
        root.get_texture().get_image().save_png("res://docs/stage15_map_review_revision/festival_map.png")
    world.map_ui.close()
    _check(not paused,"Closing map restores time")
    world.abilities.clear()
    await _go("HwaniraPlaza")
    _finish("stage15_festival_ui_capture")
