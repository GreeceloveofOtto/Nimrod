이 QA 파일을 실행 ZIP의 Nimrod 폴더에 합치면 확대4장·전체109프레임·실제장면8장·기준시트·이전시트·검증결과를 볼 수 있습니다. archive는 Godot 가져오기와 실행 ZIP에서 제외됩니다. 생성 PNG 원본과 canonical 변환 원본은 작업 workspace의 archive에 별도 보존하며 이 QA에는 포함하지 않았습니다.
